package com.app.service;

import com.app.entity.OrderItem;

public interface OrderItemService {
	
	public OrderItem createOrderItem(OrderItem orderItem);

}
