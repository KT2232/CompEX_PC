package com.app.enums;

public enum UserRole {

	ROLE_ADMIN,
	ROLE_CUSTOMER
}
