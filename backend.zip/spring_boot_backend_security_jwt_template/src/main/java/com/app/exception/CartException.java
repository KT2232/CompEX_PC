package com.app.exception;

public class CartException extends Exception {

	public CartException(String message) {

		super(message);
	}

}
