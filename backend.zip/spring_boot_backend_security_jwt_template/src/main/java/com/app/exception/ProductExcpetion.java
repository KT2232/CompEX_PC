package com.app.exception;

public class ProductExcpetion extends Exception {

	public ProductExcpetion(String message) {

		super(message);
	}

}
