package com.app.config;

public class JwtConstant {
	public static final String SECRET_KEY="sdfgdasfsdfsadsadsadasdsaasdasdsaddfhgffsd";
	public static final String JWT_HEADER="Authorization";

}
